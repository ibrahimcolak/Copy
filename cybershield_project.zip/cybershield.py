
import os
import time
import hashlib
import logging
import subprocess
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# === Ayarlar ===
WATCH_PATH = "C:/Users/Public"  # İzlenecek klasör
CLAMAV_PATH = "C:\Program Files\ClamAV\clamscan.exe"  # ClamAV yolunu kendi bilgisayarına göre değiştir
CONFIG_FILE = "config.txt"
LOG_FILE = "cyberlog.txt"
QUARANTINE_FOLDER = "quarantine"

# === Log ayarı ===
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format='[%(asctime)s] %(message)s')

# === Sistem Açık mı? ===
def is_active():
    try:
        with open(CONFIG_FILE, "r") as f:
            return f.read().strip().lower() == "aktif"
    except:
        return True  # Dosya yoksa aktif say

# === SHA256 Hesapla ===
def get_sha256(file_path):
    try:
        with open(file_path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except:
        return None

# === ClamAV ile Tarama ===
def scan_with_clamav(file_path):
    try:
        result = subprocess.run([CLAMAV_PATH, "-i", file_path], capture_output=True, text=True)
        if "Infected files: 0" in result.stdout:
            return False
        else:
            return True
    except Exception as e:
        logging.error(f"ClamAV hatası: {e}")
        return False

# === Karantinaya Al ===
def quarantine_file(file_path):
    if not os.path.exists(QUARANTINE_FOLDER):
        os.makedirs(QUARANTINE_FOLDER)
    base_name = os.path.basename(file_path)
    dest_path = os.path.join(QUARANTINE_FOLDER, f"{base_name}_{int(time.time())}")
    try:
        os.rename(file_path, dest_path)
        logging.warning(f"Karantinaya alındı: {file_path}")
        print(f"⚠️ Karantinaya alındı: {file_path}")
    except Exception as e:
        logging.error(f"Karantina hatası: {e}")

# === Dosya Olayı Yakalayıcı ===
class Handler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            handle_file(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            handle_file(event.src_path)

# === Dosya Kontrol Fonksiyonu ===
def handle_file(file_path):
    if not is_active():
        return
    logging.info(f"Yeni/Değişen dosya: {file_path}")
    print(f"[+] Dosya kontrol ediliyor: {file_path}")

    sha = get_sha256(file_path)
    if not sha:
        logging.warning(f"SHA alınamadı: {file_path}")
        return

    if scan_with_clamav(file_path):
        quarantine_file(file_path)
    else:
        logging.info(f"Temiz dosya: {file_path}")

# === Ana Fonksiyon ===
def main():
    print("🛡️ CyberShield AI çalışıyor. İzleme başlatıldı...")
    logging.info("CyberShield başlatıldı.")
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            f.write("aktif")

    event_handler = Handler()
    observer = Observer()
    observer.schedule(event_handler, WATCH_PATH, recursive=True)
    observer.start()

    try:
        while True:
            if not is_active():
                print("⏸️ Sistem pasif modda. config.txt ile aktifleştir.")
            time.sleep(10)
    except KeyboardInterrupt:
        observer.stop()
        logging.info("CyberShield manuel durduruldu.")
    observer.join()

if __name__ == "__main__":
    main()
